<?php

/* this is auto generated file */
return [
    [
        'name'         => 'admin.schedule.browse_job',
        'phrase_title' => 'schedule::phrase.schedule_jobs',
        'url'          => 'schedule/job/browse',
    ],
    [
        'name'         => 'admin.schedule.schedule_setting',
        'phrase_title' => 'core::phrase.settings',
        'url'          => 'schedule/setting',
    ],
];
