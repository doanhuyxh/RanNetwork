<?php

/* this is auto generated file */
return [
    [
        'name'       => 'seo.admin',
        'resolution' => 'admin',
        'type'       => 'admin_top',
        'title'      => 'seo::phrase.manage_seo',
    ],
];
