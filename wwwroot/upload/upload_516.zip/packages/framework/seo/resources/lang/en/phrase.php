<?php

/* this is auto generated file */
return [
    'add_new'               => 'Add New',
    'add_new_page'          => 'New Page',
    'app_name'              => 'SEO',
    'enabling_sitemap'      => 'Enabling Sitemap',
    'enabling_sitemap_desc' => 'Enable sitemap information by checking one of the boxes in the following section.',
    'entity_type_meta'      => 'meta',
    'failed_getting'        => 'Failed getting {url}',
    'open_graph'            => 'OpenGraph',
    'menu'                  => 'Menu',
    'manage_seo'            => 'Manage SEO',
    'name'                  => 'Name',
    'package_name'          => 'App Name',
    'page_description'      => 'Description',
    'page_description_desc' => 'Meta Description',
    'page_heading'          => 'Heading',
    'page_keywords'         => 'Keywords',
    'page_keywords_desc'    => 'Meta Keywords',
    'page_title'            => 'Title',
    'page_title_desc'       => 'Page Title',
    'secondary_menu'        => 'Sub Menu',
    'seo'                   => 'SEO',
    'settings'              => 'Settings',
    'sitemap_settings'      => 'Sitemap Settings',
    'title'                 => 'Title',
];
