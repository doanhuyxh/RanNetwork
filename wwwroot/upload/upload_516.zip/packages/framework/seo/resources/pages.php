<?php

/* this is auto generated file */
return [
    [
        'name'         => 'admin.seo.browse_meta',
        'phrase_title' => 'core::phrase.settings',
        'url'          => 'seo/meta/browse',
    ],
    [
        'name'         => 'admin.seo.sitemap_settings',
        'phrase_title' => 'seo::phrase.sitemap_settings',
        'url'          => 'seo/setting',
    ],
];
