<?php

namespace MetaFox\Localize\Contracts;

/**
 * Interface TimezoneSupportContract.
 * @deprecated
 */
interface TimezoneSupportContract
{
}
