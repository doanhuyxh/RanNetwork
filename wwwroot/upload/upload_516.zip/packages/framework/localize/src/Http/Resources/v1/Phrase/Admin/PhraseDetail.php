<?php

namespace MetaFox\Localize\Http\Resources\v1\Phrase\Admin;

use MetaFox\Localize\Models\Phrase as Model;

/**
 * Class PhraseItem.
 * @property Model $resource
 * @SuppressWarnings(PHPMD.UnusedFormalParameter)
 */
class PhraseDetail extends PhraseItem
{
}
