<?php

/* this is auto generated file */
return [
    'add_new_currency'            => 'Add New Currency',
    'code'                        => 'Code',
    'currency_delete_confirm'     => 'Are you sure you want to permanently delete this currency?',
    'currency_format_description' => 'Specify a currency format with the following rules:
{0} means currency symbol ($, €, ...)
{1} means currency id (USD, EUR,...)
Decimal point and thousand separator (#,###.00 ...)
Example, format is: {0} #,###.00 {1} , and price show: $ 1,000.00 USD',
    'edit_currency' => 'Edit Currency',
    'format'        => 'Format',
    'is_active'     => 'Is Active?',
    'name'          => 'Name',
    'symbol'        => 'Symbol',
];
