<?php

/* this is auto generated file */
return [
    'add_country'       => 'Add New Country',
    'city'              => 'City',
    'city_code'         => 'City Code',
    'city_name'         => 'City Name',
    'country'           => 'Country',
    'edit_country'      => 'Edit Country',
    'fill_country_name' => 'Fill in the country\'s name.',
    'filter_by_city'    => 'Filter by city',
    'fips_code'         => 'FIPS Code',
    'geonames_code'     => 'Geo Codes',
    'name_label'        => 'Name',
    'population'        => 'Population',
    'post_codes'        => 'Post Code',
    'state'             => 'State',
    'state_code'        => 'State Code',
    'state_iso'         => 'State ISO',
    'state_name'        => 'State Name',
    'translate_country' => 'Translate Country',
];
