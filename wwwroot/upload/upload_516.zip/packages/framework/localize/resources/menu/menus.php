<?php

/* this is auto generated file */
return [
    [
        'name'       => 'localize.admin',
        'resolution' => 'admin',
        'type'       => 'admin_top',
        'title'      => 'localize::phrase.manage_localize',
    ],
];
