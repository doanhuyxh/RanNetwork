<?php

/* this is auto generated file */
return [
    'filename'    => 'Filename',
    'filesize'    => 'Filesize',
    'modified_at' => 'Modified At',
];
