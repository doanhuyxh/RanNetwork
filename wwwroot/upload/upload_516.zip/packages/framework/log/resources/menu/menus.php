<?php

/* this is auto generated file */
return [
    [
        'name'       => 'log.admin',
        'resolution' => 'admin',
        'type'       => 'admin_top',
        'title'      => 'log::phrase.manage_log',
    ],
];
