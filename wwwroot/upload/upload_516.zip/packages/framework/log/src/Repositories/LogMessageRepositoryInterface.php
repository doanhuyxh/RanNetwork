<?php

namespace MetaFox\Log\Repositories;

use Prettus\Repository\Eloquent\BaseRepository;

/**
 * Interface LogMessage.
 *
 * @mixin BaseRepository
 * stub: /packages/repositories/interface.stub
 */
interface LogMessageRepositoryInterface
{
}
