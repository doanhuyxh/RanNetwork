<?php

namespace MetaFox\Attachment\Http\Resources\v1\Attachment;

use Illuminate\Http\Resources\Json\ResourceCollection;

/**
 * Class AttachmentItemCollection.
 * @ignore
 * @codeCoverageIgnore
 */
class AttachmentItemCollection extends ResourceCollection
{
    public $collects = AttachmentItem::class;
}
