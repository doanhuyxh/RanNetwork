<?php

/* this is auto generated file */
return [
    'app_name'                => 'Broadcast',
    'broadcast_setting'       => '',
    'browse_connection'       => '',
    'browse_driver'           => '',
    'connections'             => 'Connections',
    'default_connection'      => 'Default Connection',
    'default_connection_desc' => 'Use connection to broadcast event',
    'driver'                  => 'Driver',
    'pusher_setting'          => '',
];
