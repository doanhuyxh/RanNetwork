<?php

 /* this is auto generated file */
 return [
     [
         'name'       => 'broadcast.sidebarMenu',
         'resolution' => 'web',
     ],
     [
         'name'       => 'broadcast.admin',
         'resolution' => 'admin',
     ],
 ];
