<?php

/* this is auto generated file */
return [
    [
        'name'         => 'admin.broadcast.browse_connection',
        'phrase_title' => 'broadcast::phrase.connections',
        'url'          => 'broadcast/connection/browse',
    ],
];
